

CREATE TABLE `aclitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `controller` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `action` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `action_name` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `active` tinyint(2) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `controller` (`controller`,`action`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO aclitems VALUES("1","مدیریت نقش ها","roles","admin_index","لیست نقش ها","1","0000-00-00 00:00:00");
INSERT INTO aclitems VALUES("2","مدیریت نقش ها","roles","admin_add","افزودن نقش","1","0000-00-00 00:00:00");
INSERT INTO aclitems VALUES("3","مدیریت نقش ها","roles","admin_edit","ویرایش نقش","1","0000-00-00 00:00:00");
INSERT INTO aclitems VALUES("4","مدیریت نقش ها","roles","admin_delete","حذف نقش","1","0000-00-00 00:00:00");
INSERT INTO aclitems VALUES("5","مدیریت دسترسی","aclitems","admin_index","لیست دسترسی ها","1","0000-00-00 00:00:00");
INSERT INTO aclitems VALUES("6","مدیریت دسترسی","aclroles","admin_active_permission","فعال کردن دسترسی","1","0000-00-00 00:00:00");
INSERT INTO aclitems VALUES("7","مدیریت دسترسی","aclroles","admin_inactive_permission","غیرفعال کردن دسترسی","1","0000-00-00 00:00:00");
INSERT INTO aclitems VALUES("8","مدیریت کاربران","users","admin_index","لیست کاربران","1","0000-00-00 00:00:00");
INSERT INTO aclitems VALUES("9","مدیریت کاربران","users","admin_add","افزودن کاربر","1","0000-00-00 00:00:00");
INSERT INTO aclitems VALUES("10","مدیریت کاربران","users","admin_edit","ویرایش کاربر","1","0000-00-00 00:00:00");
INSERT INTO aclitems VALUES("11","مدیریت کاربران","users","admin_delete","حذف کاربر","1","0000-00-00 00:00:00");
INSERT INTO aclitems VALUES("21","manager_message_managment","managermessages","admin_index","message_list","1","2016-06-13 02:35:39");
INSERT INTO aclitems VALUES("22","manager_message_managment","managermessages","admin_add","add_message","1","2016-06-13 02:35:39");
INSERT INTO aclitems VALUES("23","manager_message_managment","managermessages","admin_edit","edit_message","1","2016-06-13 02:35:39");
INSERT INTO aclitems VALUES("24","manager_message_managment","managermessages","admin_delete","delete_message","1","2016-06-13 02:35:39");
INSERT INTO aclitems VALUES("27","مدیریت پیام مدیر عامل","managermessages","admin_index","لیست پیام ها","1","2016-06-14 15:33:47");
INSERT INTO aclitems VALUES("28","مدیریت پیام مدیر عامل","managermessages","admin_add","افزودن پیام","1","2016-06-14 15:33:48");
INSERT INTO aclitems VALUES("29","مدیریت پیام مدیر عامل","managermessages","admin_edit","ویرایش پیام","1","2016-06-14 15:33:48");
INSERT INTO aclitems VALUES("30","مدیریت پیام مدیر عامل","managermessages","admin_delete","حذف پیام","1","2016-06-14 15:33:48");
INSERT INTO aclitems VALUES("31","مدیریت محصول مدیر عامل","products","admin_index","message_list","1","2016-06-14 18:37:04");
INSERT INTO aclitems VALUES("32","مدیریت محصول مدیر عامل","products","admin_add","افزودن محصول","1","2016-06-14 18:37:04");
INSERT INTO aclitems VALUES("33","مدیریت محصول مدیر عامل","products","admin_edit","ویرایش محصول","1","2016-06-14 18:37:04");
INSERT INTO aclitems VALUES("34","مدیریت محصول مدیر عامل","products","admin_delete","حذف محصول","1","2016-06-14 18:37:04");





CREATE TABLE `aclroles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `aclitem_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `role_id` (`role_id`,`aclitem_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO aclroles VALUES("2","5","9","2016-06-06 03:02:30");
INSERT INTO aclroles VALUES("4","5","11","2016-06-06 03:02:32");
INSERT INTO aclroles VALUES("5","5","10","2016-06-06 03:02:33");
INSERT INTO aclroles VALUES("7","5","1","2016-06-06 03:02:39");
INSERT INTO aclroles VALUES("8","5","8","2016-06-06 03:02:40");
INSERT INTO aclroles VALUES("12","4","10","2016-06-06 03:05:10");
INSERT INTO aclroles VALUES("13","4","8","2016-06-06 03:05:11");
INSERT INTO aclroles VALUES("14","4","9","2016-06-06 03:05:12");
INSERT INTO aclroles VALUES("15","4","1","2016-06-06 03:05:14");
INSERT INTO aclroles VALUES("16","4","3","2016-06-06 03:05:15");
INSERT INTO aclroles VALUES("17","4","2","2016-06-06 03:05:16");
INSERT INTO aclroles VALUES("18","4","4","2016-06-06 03:05:17");
INSERT INTO aclroles VALUES("19","4","7","2016-06-06 03:05:18");
INSERT INTO aclroles VALUES("20","4","6","2016-06-06 03:05:19");
INSERT INTO aclroles VALUES("21","4","5","2016-06-06 03:05:20");
INSERT INTO aclroles VALUES("22","4","11","2016-06-06 03:05:26");





CREATE TABLE `manager_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `message` varchar(300) COLLATE utf8_persian_ci NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO manager_messages VALUES("1","4","تلاش ما در شرکت جام نمای فردوس ، رضایت خاطر شما مشتریان عزیز است. با این رویکرد تیمی متخصص و متعهد را شکل داده ایم تا پروژه های شما را به بهترین شکل ممکن انجام دهیم.اعتماد شما سرمایه حقیقی ماست...","1","2016-06-14 15:36:03");
INSERT INTO manager_messages VALUES("3","5","ویژگی متمایز ما نسبت به سایرهمکارانمان تخصص و در عین حال تعهد تیم اجرایی ماست. بهترین های این صنعت را جمع کرده ایم تا محصولی شایسته شما مشتری عزیز را تولید و اجرا کنیم. لبخند رضایت شما، انرژی مضاعف به ما در ارائه خدمات بهتر خواهد داد... ","1","2016-06-14 16:03:10");





CREATE TABLE `pages` (
  `id` int(11) NOT NULL,
  `title` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `body` text COLLATE utf8_persian_ci NOT NULL,
  `meta` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `keyword` varchar(300) COLLATE utf8_persian_ci NOT NULL,
  `arrangment` tinyint(2) NOT NULL,
  `status` tinyint(2) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO pages VALUES("1","درباره ما","&lt;p style=&quot;text-align: right;&quot;&gt;\\n	جام نمای فردوس از اولبین شرکت های صنایع شیشه در تهران می باشد که کار خود را از سال 1320 آغاز کرده است..&lt;/p&gt;\\n&lt;p style=&quot;text-align: right;&quot;&gt;\\n	این شرکت دارای بخش های زیر می باشد&lt;/p&gt;\\n","جام نمای فردوس","جام نما#فردوس","0","1","0000-00-00 00:00:00");
INSERT INTO pages VALUES("2","تماس با ما","","","","0","0","0000-00-00 00:00:00");





CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO plugins VALUES("10","Hello","1","2016-06-13 03:10:54");
INSERT INTO plugins VALUES("11","Manager","1","2016-06-14 15:33:48");
INSERT INTO plugins VALUES("12","Product","0","2016-06-14 18:37:04");





CREATE TABLE `productimages` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) NOT NULL,
  `title` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `image` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;






CREATE TABLE `products` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(300) COLLATE utf8_persian_ci NOT NULL,
  `detail` text COLLATE utf8_persian_ci NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;






CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1= active , 0= inactive',
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO roles VALUES("1","برنامه نویس سایت","1","2013-04-25 02:56:11");
INSERT INTO roles VALUES("2","کاربر عادی","1","2013-05-05 08:43:56");
INSERT INTO roles VALUES("4","مدیر کل سایت","1","2013-05-05 09:22:02");
INSERT INTO roles VALUES("5","بلاگر","0","2013-10-02 11:46:50");





CREATE TABLE `settings` (
  `site_title` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `site_keywords` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `site_description` varchar(700) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;






CREATE TABLE `user_log_logins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `count_login` int(11) NOT NULL DEFAULT '1',
  `modified` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;






CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  `sex` tinyint(4) NOT NULL DEFAULT '-1',
  `age` smallint(6) NOT NULL,
  `user_name` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL COMMENT 'full url to image file',
  `status` smallint(6) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `last_login` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`,`user_name`),
  KEY `role_id` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO users VALUES("1","1","مجتبي پوراصغر","1","0","","cca908a919a6e26163db7282813429d6a6ec75fe","pourasghar2006@gmail.com","","1","2013-11-19 00:00:00","2013-08-01 09:12:38","2013-12-28 13:26:05");
INSERT INTO users VALUES("4","4","بهروز عاشوری","1","0","behrooz","5b74ec483dea5a8b8d8fb2890ab1c4f19db4de45","behrooz.ashori@gmail.com","25d820121b1dc8c129b70725c8bce78c.jpg","1","2016-06-13 00:00:15","2016-06-13 00:00:15","0000-00-00 00:00:00");
INSERT INTO users VALUES("5","4","جعفر لامعی","1","0","jafar","69ea94b3c2a9364efe04c78d4b45ed560101862b","jafar@gmail.com","2a248059eb3fa09750f47e1339998603.jpg","1","2016-06-13 00:37:47","2016-06-13 00:39:38","0000-00-00 00:00:00");



